import Header from "@/components/header"
import Hero from "@/components/hero"
import Clients from "@/components/clients"
import Services from "@/components/services"
import WorkProcess from "@/components/work-process"
import Values from "@/components/values"
import FeaturedWork from "@/components/featured-work"
import Contact from "@/components/contact"
import LatestNews from "@/components/latest-news"
import Footer from "@/components/footer"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1">
        <Hero />
        <Clients />
        <Services />
        <WorkProcess />
        <Values />
        <FeaturedWork />
        <Contact />
        <LatestNews />
      </main>
      <Footer />
    </div>
  )
}
