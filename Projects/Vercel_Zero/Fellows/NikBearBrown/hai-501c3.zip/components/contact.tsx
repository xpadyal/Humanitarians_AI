import { Button } from "@/components/ui/button"

export default function Contact() {
  return (
    <section className="w-full py-12 md:py-24 border-b">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div className="space-y-4 relative">
            <span className="text-sm uppercase">Join Our Mission</span>
            <h2 className="text-4xl md:text-5xl font-bold tracking-tighter">HELP US USE AI FOR THE GREATER GOOD</h2>
            <div className="absolute -bottom-12 left-0">
              <div className="space-y-1">
                {[1, 2, 3, 4].map((_, i) => (
                  <div key={i} className="h-1 w-8 bg-foreground"></div>
                ))}
              </div>
            </div>
          </div>
          <div className="md:pl-12 space-y-6">
            <p className="text-muted-foreground">
              Your support helps us develop ethical AI solutions that address real-world challenges in education,
              healthcare, nonprofits, and the arts. Join us in our mission to ensure AI benefits everyone, especially
              underserved communities.
            </p>
            <div className="flex flex-wrap gap-4">
              <Button className="uppercase text-xs">Donate Now</Button>
              <Button variant="outline" className="uppercase text-xs">
                Volunteer
              </Button>
              <Button variant="outline" className="uppercase text-xs">
                Subscribe
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
