"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { ThemeToggle } from "@/components/theme-toggle"
import Logo from "@/components/logo"

export default function Header() {
  const pathname = usePathname()

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-6 md:gap-10">
          <Link href="/" className="flex items-center space-x-2">
            <Logo />
            <span className="hidden font-bold sm:inline-block">H.AI</span>
          </Link>
        </div>
        <nav className="hidden md:flex items-center gap-6">
          <Link
            href="/services"
            className={cn(
              "text-sm font-medium uppercase transition-colors hover:text-foreground/80",
              pathname === "/services" ? "text-foreground" : "text-foreground/60",
            )}
          >
            Services
          </Link>
          <Link
            href="/work"
            className={cn(
              "text-sm font-medium uppercase transition-colors hover:text-foreground/80",
              pathname === "/work" ? "text-foreground" : "text-foreground/60",
            )}
          >
            Work
          </Link>
          <Link
            href="/studio"
            className={cn(
              "text-sm font-medium uppercase transition-colors hover:text-foreground/80",
              pathname === "/studio" ? "text-foreground" : "text-foreground/60",
            )}
          >
            Studio
          </Link>
          <Link
            href="/blog"
            className={cn(
              "text-sm font-medium uppercase transition-colors hover:text-foreground/80",
              pathname === "/blog" ? "text-foreground" : "text-foreground/60",
            )}
          >
            Blog
          </Link>
          <div className="relative group">
            <button className="text-sm font-medium uppercase transition-colors hover:text-foreground/80 text-foreground/60">
              Pages
            </button>
            <div className="absolute left-0 top-full hidden group-hover:block bg-background border rounded-md shadow-md p-2 min-w-40">
              <Link href="/about" className="block px-3 py-2 text-sm hover:bg-muted rounded-sm">
                About
              </Link>
              <Link href="/contact" className="block px-3 py-2 text-sm hover:bg-muted rounded-sm">
                Contact
              </Link>
              <Link href="/pricing" className="block px-3 py-2 text-sm hover:bg-muted rounded-sm">
                Pricing
              </Link>
              <Link href="/faq" className="block px-3 py-2 text-sm hover:bg-muted rounded-sm">
                FAQ
              </Link>
            </div>
          </div>
        </nav>
        <div className="flex items-center gap-2">
          <Button variant="default" className="rounded-none uppercase text-xs font-medium">
            Donate Now
          </Button>
          <div className="flex items-center gap-1 ml-2">
            <Link href="https://linkedin.com" className="size-8 flex items-center justify-center rounded-full border">
              <span className="sr-only">LinkedIn</span>
              <span className="text-xs">IN</span>
            </Link>
            <Link href="https://pinterest.com" className="size-8 flex items-center justify-center rounded-full border">
              <span className="sr-only">Pinterest</span>
              <span className="text-xs">PT</span>
            </Link>
            <Link href="https://twitter.com" className="size-8 flex items-center justify-center rounded-full border">
              <span className="sr-only">Twitter</span>
              <span className="text-xs">TW</span>
            </Link>
          </div>
          <ThemeToggle />
        </div>
      </div>
    </header>
  )
}
