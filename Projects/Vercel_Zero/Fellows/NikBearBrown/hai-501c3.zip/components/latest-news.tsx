import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function LatestNews() {
  return (
    <section className="w-full py-12 md:py-24 border-b">
      <div className="container">
        <div className="flex justify-between items-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold">LATEST NEWS</h2>
          <Button variant="outline" className="uppercase text-xs">
            See All
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <Link href="/blog/fellows-program" className="group">
            <div className="space-y-4">
              <Image
                src="/placeholder.svg?height=300&width=400"
                width={400}
                height={300}
                alt="Fellows Program"
                className="w-full object-cover transition-transform group-hover:scale-105"
              />
              <div className="space-y-2">
                <span className="text-xs uppercase">EDUCATION</span>
                <h3 className="text-xl font-medium group-hover:underline">
                  Applications Now Open for 2023 Humanitarians AI Fellows Program
                </h3>
              </div>
            </div>
          </Link>

          <Link href="/blog/ai-healthcare" className="group">
            <div className="space-y-4">
              <Image
                src="/placeholder.svg?height=300&width=400"
                width={400}
                height={300}
                alt="AI in Healthcare"
                className="w-full object-cover transition-transform group-hover:scale-105"
              />
              <div className="space-y-2">
                <span className="text-xs uppercase">HEALTHCARE</span>
                <h3 className="text-xl font-medium group-hover:underline">
                  New PredictaBio Project Aims to Revolutionize Protein Synthesis
                </h3>
              </div>
            </div>
          </Link>

          <Link href="/blog/project-tapestry" className="group">
            <div className="space-y-4">
              <Image
                src="/placeholder.svg?height=300&width=400"
                width={400}
                height={300}
                alt="Project Tapestry"
                className="w-full object-cover transition-transform group-hover:scale-105"
              />
              <div className="space-y-2">
                <span className="text-xs uppercase">SOCIAL GOOD</span>
                <h3 className="text-xl font-medium group-hover:underline">
                  Project Tapestry Connects 500+ Job Seekers with Opportunities
                </h3>
              </div>
            </div>
          </Link>
        </div>
      </div>
    </section>
  )
}
