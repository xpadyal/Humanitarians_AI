import Image from "next/image"
import { Button } from "@/components/ui/button"

export default function FeaturedWork() {
  return (
    <section className="w-full py-12 md:py-24 border-b">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">FEATURED PROJECTS</h2>
            <p className="text-muted-foreground">
              Showcasing our innovative AI solutions that address real-world challenges in education, healthcare, and
              social good.
            </p>
          </div>
          <div className="flex justify-start md:justify-end items-end">
            <Button variant="outline" className="uppercase text-xs">
              See All Projects
            </Button>
          </div>
        </div>

        <div className="space-y-8">
          <div className="relative">
            <Image
              src="/placeholder.svg?height=500&width=1000"
              width={1000}
              height={500}
              alt="Intelligent AI Books"
              className="w-full object-cover"
            />
            <div className="mt-4 flex justify-between items-center">
              <h3 className="text-xl font-bold">Intelligent AI Books</h3>
              <span className="text-sm">2023</span>
            </div>
            <p className="text-muted-foreground mt-2">
              Personalized conversational learning that adapts in real-time based on the user's background, learning
              style, and goals.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="relative">
              <Image
                src="/placeholder.svg?height=400&width=500"
                width={500}
                height={400}
                alt="Project Dewey"
                className="w-full object-cover"
              />
              <div className="mt-4 flex justify-between items-center">
                <h3 className="text-xl font-bold">Project Dewey</h3>
                <span className="text-sm">2023</span>
              </div>
              <p className="text-muted-foreground mt-2">
                Educational AI tools including Ada for calculus, Newton for physics, and Grace for algorithms.
              </p>
            </div>
            <div className="relative">
              <Image
                src="/placeholder.svg?height=400&width=500"
                width={500}
                height={400}
                alt="The Shannon Project"
                className="w-full object-cover"
              />
              <div className="mt-4 flex justify-between items-center">
                <h3 className="text-xl font-bold">The Shannon Project</h3>
                <span className="text-sm">2023</span>
              </div>
              <p className="text-muted-foreground mt-2">
                Open-source AI tools for education leveraging Claude Enterprise and LLMs.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
