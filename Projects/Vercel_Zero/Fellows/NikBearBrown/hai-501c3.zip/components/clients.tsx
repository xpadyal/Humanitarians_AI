import Image from "next/image"

export default function Clients() {
  return (
    <section className="w-full py-12 border-b">
      <div className="container">
        <h2 className="text-sm font-medium uppercase mb-8">Our Clients</h2>
        <div className="flex overflow-x-auto pb-4 gap-12 items-center">
          <div className="flex-shrink-0">
            <Image
              src="/placeholder.svg?height=60&width=120"
              width={120}
              height={60}
              alt="Abstract"
              className="object-contain"
            />
            <span className="mt-2 text-xs text-center block">Abstract</span>
          </div>
          <div className="flex-shrink-0">
            <Image
              src="/placeholder.svg?height=60&width=120"
              width={120}
              height={60}
              alt="Vision Studio"
              className="object-contain"
            />
            <span className="mt-2 text-xs text-center block">Vision Studio</span>
          </div>
          <div className="flex-shrink-0">
            <Image
              src="/placeholder.svg?height=60&width=120"
              width={120}
              height={60}
              alt="In Motion"
              className="object-contain"
            />
            <span className="mt-2 text-xs text-center block">In Motion</span>
          </div>
          <div className="flex-shrink-0">
            <Image
              src="/placeholder.svg?height=60&width=120"
              width={120}
              height={60}
              alt="Creative Studio"
              className="object-contain"
            />
            <span className="mt-2 text-xs text-center block">Creative Studio</span>
          </div>
          <div className="flex-shrink-0">
            <Image
              src="/placeholder.svg?height=60&width=120"
              width={120}
              height={60}
              alt="In Motion"
              className="object-contain"
            />
            <span className="mt-2 text-xs text-center block">In Motion</span>
          </div>
        </div>
      </div>
    </section>
  )
}
