import Image from "next/image"
import { Diamond } from "lucide-react"

export default function Hero() {
  return (
    <section className="w-full py-12 md:py-24 border-b">
      <div className="container grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
        <div className="space-y-4 relative">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tighter">
            Harnessing AI for social good.
          </h1>
          <p className="text-muted-foreground max-w-[600px]">
            A 501(c)(3) nonprofit organization dedicated to developing ethical AI solutions that address real-world
            challenges in education, healthcare, nonprofits, and the arts.
          </p>
          <div className="absolute -bottom-12 left-0">
            <Diamond className="size-16 stroke-1" />
          </div>
        </div>
        <div className="relative">
          <Image
            src="/placeholder.svg?height=500&width=600"
            width={600}
            height={500}
            alt="Team members collaborating on AI solutions"
            className="object-cover"
          />
        </div>
      </div>
    </section>
  )
}
